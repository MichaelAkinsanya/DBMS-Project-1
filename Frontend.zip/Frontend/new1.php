
<<?php
	$UsernamePasswordId = $_GET['UsernamePasswordId'];
	$StudentID = $_GET['StudentID'];
	$username = $_GET['username'];
	$Password = $_GET['Password'];

	// Database connection
	$conn = new mysqli('localhost','root',' ','students');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into creds(UsernamePasswordID, StudentID, username, Password) values(?, ?, ?, ?)");
		$stmt->bind_param("iiss", $UsernamePasswordId, $StudentID, $username, $Password);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successful...";
		$stmt->close();
		$conn->close();
	}
?>